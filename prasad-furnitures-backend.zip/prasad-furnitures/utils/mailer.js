// utils/mailer.js – sends email notifications on new enquiries
const nodemailer = require('nodemailer');

let transporter = null;

const getTransporter = () => {
  if (!process.env.SMTP_USER || !process.env.SMTP_PASS) return null;
  if (transporter) return transporter;

  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST || 'smtp.gmail.com',
    port: parseInt(process.env.SMTP_PORT || '587'),
    secure: false,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });

  return transporter;
};

const sendEnquiryNotification = async (enquiry) => {
  const t = getTransporter();
  if (!t || !process.env.OWNER_EMAIL) return; // skip if not configured

  const mailOptions = {
    from: `"Prasad Furnitures Website" <${process.env.SMTP_USER}>`,
    to: process.env.OWNER_EMAIL,
    subject: `New Enquiry from ${enquiry.name} – ${enquiry.interest}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; padding: 24px; border: 1px solid #eee;">
        <h2 style="color: #8B5A2B;">New Customer Enquiry</h2>
        <table style="width:100%; border-collapse: collapse;">
          <tr><td style="padding:8px 0; color:#555; font-size:13px;">Name</td><td><strong>${enquiry.name}</strong></td></tr>
          <tr><td style="padding:8px 0; color:#555; font-size:13px;">Phone / WhatsApp</td><td><strong>${enquiry.phone}</strong></td></tr>
          <tr><td style="padding:8px 0; color:#555; font-size:13px;">Interest</td><td>${enquiry.interest}</td></tr>
          <tr><td style="padding:8px 0; color:#555; font-size:13px;">Message</td><td>${enquiry.message || '–'}</td></tr>
          <tr><td style="padding:8px 0; color:#555; font-size:13px;">Submitted At</td><td>${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}</td></tr>
        </table>
        <p style="margin-top:24px;">
          <a href="https://wa.me/${process.env.WHATSAPP_NUMBER || '918686603034'}?text=Hi+${encodeURIComponent(enquiry.name)}" 
             style="background:#25D366;color:#fff;padding:10px 20px;text-decoration:none;border-radius:4px;font-weight:bold;">
            Reply on WhatsApp
          </a>
        </p>
      </div>
    `,
  };

  try {
    await t.sendMail(mailOptions);
  } catch (err) {
    console.warn('[Mailer] Could not send email:', err.message);
  }
};

module.exports = { sendEnquiryNotification };

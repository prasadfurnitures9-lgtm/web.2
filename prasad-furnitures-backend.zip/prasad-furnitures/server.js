// server.js – Prasad Furnitures Backend
require('dotenv').config();

const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');
const path = require('path');
const rateLimit = require('express-rate-limit');

const app = express();
const PORT = process.env.PORT || 3000;

// ─── Security & Middleware ────────────────────────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "fonts.googleapis.com"],
      styleSrc:  ["'self'", "'unsafe-inline'", "fonts.googleapis.com", "fonts.gstatic.com"],
      fontSrc:   ["'self'", "fonts.gstatic.com"],
      imgSrc:    ["'self'", "data:", "blob:"],
      connectSrc:["'self'"],
    },
  },
}));
app.use(cors({
  origin: process.env.NODE_ENV === 'production'
    ? ['https://prasadfurnitures.com', 'https://www.prasadfurnitures.com']
    : '*',
}));
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));

// ─── Rate Limiting ────────────────────────────────────────────────────────────
const enquiryLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10,
  message: { error: 'Too many enquiries submitted. Please try again in 15 minutes.' },
  standardHeaders: true,
  legacyHeaders: false,
});

const apiLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 100,
  standardHeaders: true,
});

app.use('/api/', apiLimiter);
app.use('/api/enquiries', enquiryLimiter);

// ─── Static Files ─────────────────────────────────────────────────────────────
// Serve uploaded product images
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
// Serve the main website
app.use(express.static(path.join(__dirname, 'public')));
// Serve admin panel
app.use('/admin', express.static(path.join(__dirname, 'admin')));

// ─── API Routes ───────────────────────────────────────────────────────────────
app.use('/api/products',     require('./routes/products'));
app.use('/api/enquiries',    require('./routes/enquiries'));
app.use('/api/testimonials', require('./routes/testimonials'));
app.use('/api/settings',     require('./routes/settings'));

// ─── Health Check ─────────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: Math.floor(process.uptime()),
    env: process.env.NODE_ENV || 'development',
  });
});

// ─── SPA Fallback (admin) ─────────────────────────────────────────────────────
app.get('/admin*', (req, res) => {
  res.sendFile(path.join(__dirname, 'admin', 'index.html'));
});

// ─── 404 Handler ──────────────────────────────────────────────────────────────
app.use((req, res) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: `Route ${req.method} ${req.path} not found` });
  }
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ─── Global Error Handler ─────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('[Error]', err.message);
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(400).json({ error: 'File too large. Max 5MB allowed.' });
  }
  res.status(err.status || 500).json({
    error: process.env.NODE_ENV === 'production' ? 'Internal server error' : err.message,
  });
});

// ─── Start ────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`
╔══════════════════════════════════════════════╗
║   Prasad Furnitures Backend                  ║
╠══════════════════════════════════════════════╣
║  🌐  Website   → http://localhost:${PORT}       ║
║  🔧  Admin     → http://localhost:${PORT}/admin ║
║  📡  API       → http://localhost:${PORT}/api   ║
╚══════════════════════════════════════════════╝
  `);
});

module.exports = app;

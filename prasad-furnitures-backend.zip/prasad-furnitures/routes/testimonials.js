// routes/testimonials.js
const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const db = require('../db');
const { requireAdmin } = require('../middleware/auth');

// GET /api/testimonials – public
router.get('/', (req, res) => {
  const rows = db.prepare(
    'SELECT * FROM testimonials WHERE is_visible = 1 ORDER BY sort_order ASC'
  ).all();
  res.json(rows);
});

// GET /api/testimonials/all – admin (includes hidden)
router.get('/all', requireAdmin, (req, res) => {
  res.json(db.prepare('SELECT * FROM testimonials ORDER BY sort_order ASC').all());
});

// POST /api/testimonials – admin create
router.post('/', requireAdmin, (req, res) => {
  const { author, location, text, stars = 5, sort_order = 0 } = req.body;
  if (!author || !text) return res.status(400).json({ error: 'author and text are required' });

  const id = 'testi_' + uuidv4().slice(0, 8);
  db.prepare(
    'INSERT INTO testimonials (id, author, location, text, stars, sort_order) VALUES (?, ?, ?, ?, ?, ?)'
  ).run(id, author, location || null, text, parseInt(stars), parseInt(sort_order));

  res.status(201).json(db.prepare('SELECT * FROM testimonials WHERE id = ?').get(id));
});

// PUT /api/testimonials/:id – admin update
router.put('/:id', requireAdmin, (req, res) => {
  const t = db.prepare('SELECT * FROM testimonials WHERE id = ?').get(req.params.id);
  if (!t) return res.status(404).json({ error: 'Testimonial not found' });

  db.prepare(`
    UPDATE testimonials SET author=?, location=?, text=?, stars=?, is_visible=?, sort_order=? WHERE id=?
  `).run(
    req.body.author || t.author,
    req.body.location ?? t.location,
    req.body.text || t.text,
    req.body.stars !== undefined ? parseInt(req.body.stars) : t.stars,
    req.body.is_visible !== undefined ? (req.body.is_visible ? 1 : 0) : t.is_visible,
    req.body.sort_order !== undefined ? parseInt(req.body.sort_order) : t.sort_order,
    req.params.id,
  );
  res.json(db.prepare('SELECT * FROM testimonials WHERE id = ?').get(req.params.id));
});

// DELETE /api/testimonials/:id – admin delete
router.delete('/:id', requireAdmin, (req, res) => {
  if (!db.prepare('SELECT id FROM testimonials WHERE id = ?').get(req.params.id))
    return res.status(404).json({ error: 'Not found' });
  db.prepare('DELETE FROM testimonials WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

module.exports = router;

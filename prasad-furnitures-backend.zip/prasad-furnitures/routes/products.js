// routes/products.js
const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { body, validationResult } = require('express-validator');
const db = require('../db');
const { requireAdmin } = require('../middleware/auth');

// ─── Multer config for product image uploads ─────────────────────────────────
const uploadsDir = path.join(__dirname, '..', 'uploads', 'products');
fs.mkdirSync(uploadsDir, { recursive: true });

const storage = multer.diskStorage({
  destination: uploadsDir,
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `product_${Date.now()}${ext}`);
  },
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5 MB
  fileFilter: (req, file, cb) => {
    if (/^image\/(jpeg|png|webp)$/.test(file.mimetype)) cb(null, true);
    else cb(new Error('Only JPEG, PNG, or WebP images are allowed'));
  },
});

// ─── GET /api/products – public list ─────────────────────────────────────────
router.get('/', (req, res) => {
  const { category, featured } = req.query;
  let sql = 'SELECT * FROM products';
  const params = [];
  const conditions = [];

  if (category) { conditions.push('category = ?'); params.push(category); }
  if (featured === '1') { conditions.push('is_featured = 1'); }

  if (conditions.length) sql += ' WHERE ' + conditions.join(' AND ');
  sql += ' ORDER BY sort_order ASC, created_at DESC';

  res.json(db.prepare(sql).all(...params));
});

// ─── GET /api/products/:id – single product ───────────────────────────────────
router.get('/:id', (req, res) => {
  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!product) return res.status(404).json({ error: 'Product not found' });
  res.json(product);
});

// ─── POST /api/products – admin create ───────────────────────────────────────
router.post('/',
  requireAdmin,
  upload.single('image'),
  [
    body('name').trim().notEmpty().withMessage('Name is required'),
    body('category').trim().notEmpty().withMessage('Category is required'),
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const id = 'prod_' + uuidv4().slice(0, 8);
    const imageUrl = req.file ? `/uploads/products/${req.file.filename}` : null;

    const stmt = db.prepare(`
      INSERT INTO products (id, name, category, description, badge, emoji, image_url, price_range, is_featured, sort_order)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    stmt.run(
      id,
      req.body.name,
      req.body.category,
      req.body.description || null,
      req.body.badge || null,
      req.body.emoji || '🪑',
      imageUrl,
      req.body.price_range || null,
      req.body.is_featured === '1' ? 1 : 0,
      parseInt(req.body.sort_order || '0'),
    );

    res.status(201).json(db.prepare('SELECT * FROM products WHERE id = ?').get(id));
  }
);

// ─── PUT /api/products/:id – admin update ────────────────────────────────────
router.put('/:id',
  requireAdmin,
  upload.single('image'),
  (req, res) => {
    const existing = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
    if (!existing) return res.status(404).json({ error: 'Product not found' });

    const imageUrl = req.file
      ? `/uploads/products/${req.file.filename}`
      : (req.body.remove_image === '1' ? null : existing.image_url);

    db.prepare(`
      UPDATE products
      SET name=?, category=?, description=?, badge=?, emoji=?, image_url=?,
          price_range=?, is_featured=?, sort_order=?, updated_at=datetime('now')
      WHERE id=?
    `).run(
      req.body.name || existing.name,
      req.body.category || existing.category,
      req.body.description ?? existing.description,
      req.body.badge ?? existing.badge,
      req.body.emoji || existing.emoji,
      imageUrl,
      req.body.price_range ?? existing.price_range,
      req.body.is_featured !== undefined ? (req.body.is_featured === '1' ? 1 : 0) : existing.is_featured,
      req.body.sort_order !== undefined ? parseInt(req.body.sort_order) : existing.sort_order,
      req.params.id,
    );

    res.json(db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id));
  }
);

// ─── DELETE /api/products/:id – admin delete ─────────────────────────────────
router.delete('/:id', requireAdmin, (req, res) => {
  const existing = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Product not found' });

  // Delete image file if exists
  if (existing.image_url) {
    const filePath = path.join(__dirname, '..', existing.image_url);
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
  }

  db.prepare('DELETE FROM products WHERE id = ?').run(req.params.id);
  res.json({ success: true, deleted: req.params.id });
});

module.exports = router;

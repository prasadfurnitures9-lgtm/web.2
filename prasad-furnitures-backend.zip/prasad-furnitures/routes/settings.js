// routes/settings.js
const express = require('express');
const router = express.Router();
const db = require('../db');
const { requireAdmin } = require('../middleware/auth');

// GET /api/settings – public (for frontend to read business info)
router.get('/', (req, res) => {
  const rows = db.prepare('SELECT key, value, label FROM settings').all();
  const obj = {};
  rows.forEach(r => { obj[r.key] = r.value; });
  res.json(obj);
});

// PATCH /api/settings – admin bulk update
router.patch('/', requireAdmin, (req, res) => {
  const update = db.prepare(
    "UPDATE settings SET value=?, updated_at=datetime('now') WHERE key=?"
  );
  const updateMany = db.transaction((entries) => {
    for (const [key, value] of entries) {
      update.run(value, key);
    }
  });
  updateMany(Object.entries(req.body));
  const rows = db.prepare('SELECT key, value FROM settings').all();
  const obj = {};
  rows.forEach(r => { obj[r.key] = r.value; });
  res.json(obj);
});

module.exports = router;

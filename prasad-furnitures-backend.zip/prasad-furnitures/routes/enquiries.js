// routes/enquiries.js
const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
const db = require('../db');
const { requireAdmin } = require('../middleware/auth');
const { sendEnquiryNotification } = require('../utils/mailer');

// ─── POST /api/enquiries – public form submission ─────────────────────────────
router.post('/',
  [
    body('name').trim().notEmpty().withMessage('Name is required'),
    body('phone').trim().notEmpty().withMessage('Phone number is required')
      .matches(/^[0-9\s\+\-]{7,15}$/).withMessage('Enter a valid phone number'),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const id = 'enq_' + uuidv4().slice(0, 8);
    const { name, phone, interest, message } = req.body;

    db.prepare(`
      INSERT INTO enquiries (id, name, phone, interest, message, source)
      VALUES (?, ?, ?, ?, ?, 'website')
    `).run(id, name, phone, interest || null, message || null);

    // Fire-and-forget email notification
    sendEnquiryNotification({ name, phone, interest, message });

    // Build WhatsApp redirect URL for the frontend to use
    const waText = `Hello Prasad Furnitures. I am ${name}. I am interested in: ${interest || 'General Enquiry'}. ${message ? 'Message: ' + message + '. ' : ''}My number: ${phone}`;
    const waUrl = `https://wa.me/${process.env.WHATSAPP_NUMBER || '918686603034'}?text=${encodeURIComponent(waText)}`;

    res.status(201).json({
      success: true,
      id,
      whatsapp_url: waUrl,
      message: 'Enquiry received! Redirecting to WhatsApp...',
    });
  }
);

// ─── GET /api/enquiries – admin list ─────────────────────────────────────────
router.get('/', requireAdmin, (req, res) => {
  const { status, page = 1, limit = 20 } = req.query;
  const offset = (parseInt(page) - 1) * parseInt(limit);

  let sql = 'SELECT * FROM enquiries';
  const params = [];
  if (status) { sql += ' WHERE status = ?'; params.push(status); }
  sql += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
  params.push(parseInt(limit), offset);

  const total = db.prepare(`SELECT COUNT(*) as c FROM enquiries${status ? ' WHERE status = ?' : ''}`).get(...(status ? [status] : []));
  const rows = db.prepare(sql).all(...params);

  res.json({ total: total.c, page: parseInt(page), limit: parseInt(limit), data: rows });
});

// ─── GET /api/enquiries/:id – admin single ────────────────────────────────────
router.get('/:id', requireAdmin, (req, res) => {
  const enq = db.prepare('SELECT * FROM enquiries WHERE id = ?').get(req.params.id);
  if (!enq) return res.status(404).json({ error: 'Enquiry not found' });
  res.json(enq);
});

// ─── PATCH /api/enquiries/:id – admin update status/notes ────────────────────
router.patch('/:id', requireAdmin, (req, res) => {
  const enq = db.prepare('SELECT * FROM enquiries WHERE id = ?').get(req.params.id);
  if (!enq) return res.status(404).json({ error: 'Enquiry not found' });

  const allowedStatuses = ['new', 'contacted', 'converted', 'closed'];
  const status = req.body.status && allowedStatuses.includes(req.body.status)
    ? req.body.status : enq.status;

  db.prepare(`
    UPDATE enquiries SET status=?, notes=?, updated_at=datetime('now') WHERE id=?
  `).run(status, req.body.notes ?? enq.notes, req.params.id);

  res.json(db.prepare('SELECT * FROM enquiries WHERE id = ?').get(req.params.id));
});

// ─── DELETE /api/enquiries/:id – admin delete ─────────────────────────────────
router.delete('/:id', requireAdmin, (req, res) => {
  const enq = db.prepare('SELECT * FROM enquiries WHERE id = ?').get(req.params.id);
  if (!enq) return res.status(404).json({ error: 'Enquiry not found' });
  db.prepare('DELETE FROM enquiries WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// ─── GET /api/enquiries/stats/summary – admin dashboard stats ────────────────
router.get('/stats/summary', requireAdmin, (req, res) => {
  const total = db.prepare('SELECT COUNT(*) as c FROM enquiries').get().c;
  const byStatus = db.prepare(`
    SELECT status, COUNT(*) as count FROM enquiries GROUP BY status
  `).all();
  const today = db.prepare(`
    SELECT COUNT(*) as c FROM enquiries WHERE date(created_at) = date('now')
  `).get().c;
  const thisWeek = db.prepare(`
    SELECT COUNT(*) as c FROM enquiries WHERE created_at >= datetime('now', '-7 days')
  `).get().c;

  res.json({ total, today, thisWeek, byStatus });
});

module.exports = router;

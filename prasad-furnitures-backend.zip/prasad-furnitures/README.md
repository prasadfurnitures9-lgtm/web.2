# Prasad Furnitures – Backend

Node.js + Express backend for the Prasad Furnitures website.

## Tech Stack
- **Runtime**: Node.js 18+
- **Framework**: Express 4
- **Database**: SQLite via `better-sqlite3` (zero setup, single file)
- **Security**: Helmet, CORS, express-rate-limit
- **File Uploads**: Multer (product images)
- **Email**: Nodemailer (optional)
- **Validation**: express-validator

## Quick Start

### 1. Install dependencies
```bash
npm install
```

### 2. Configure environment
Edit `.env` with your details:
```
ADMIN_USERNAME=admin
ADMIN_PASSWORD=your_secure_password

# Optional – for email notifications:
SMTP_USER=your_gmail@gmail.com
SMTP_PASS=your_app_password
OWNER_EMAIL=your_gmail@gmail.com
```

### 3. Start the server
```bash
# Development (auto-reload)
npm run dev

# Production
npm start
```

### 4. Open in browser
| URL | Description |
|-----|-------------|
| http://localhost:3000 | Main website |
| http://localhost:3000/admin | Admin panel |
| http://localhost:3000/api/health | Health check |

---

## API Reference

### Public Endpoints

| Method | URL | Description |
|--------|-----|-------------|
| GET | `/api/products` | List all products |
| GET | `/api/products?category=X` | Filter by category |
| GET | `/api/products/:id` | Get single product |
| POST | `/api/enquiries` | Submit enquiry (from contact form) |
| GET | `/api/testimonials` | List visible testimonials |
| GET | `/api/settings` | Get business settings |

### Admin Endpoints (HTTP Basic Auth required)

| Method | URL | Description |
|--------|-----|-------------|
| POST | `/api/products` | Add product (with image upload) |
| PUT | `/api/products/:id` | Update product |
| DELETE | `/api/products/:id` | Delete product |
| GET | `/api/enquiries` | List all enquiries |
| GET | `/api/enquiries/stats/summary` | Dashboard stats |
| PATCH | `/api/enquiries/:id` | Update status / notes |
| DELETE | `/api/enquiries/:id` | Delete enquiry |
| GET | `/api/testimonials/all` | All testimonials (incl. hidden) |
| POST | `/api/testimonials` | Add testimonial |
| PUT | `/api/testimonials/:id` | Update testimonial |
| DELETE | `/api/testimonials/:id` | Delete testimonial |
| PATCH | `/api/settings` | Update business settings |

---

## Folder Structure
```
prasad-furnitures/
├── server.js           # Main entry point
├── db.js               # SQLite setup & seed data
├── package.json
├── .env                # Environment config
├── public/             # Frontend (index.html)
├── admin/              # Admin panel
├── uploads/
│   └── products/       # Uploaded product images
├── routes/
│   ├── products.js
│   ├── enquiries.js
│   ├── testimonials.js
│   └── settings.js
├── middleware/
│   └── auth.js         # HTTP Basic Auth
├── utils/
│   └── mailer.js       # Email notifications
└── data/
    └── prasad.db       # SQLite database (auto-created)
```

## Production Deployment (VPS/Cloud)

```bash
# Install PM2 process manager
npm install -g pm2

# Start with PM2
pm2 start server.js --name "prasad-furnitures"
pm2 save
pm2 startup

# With Nginx reverse proxy (example config):
# proxy_pass http://localhost:3000;
```

## Gmail App Password Setup
1. Go to Google Account → Security
2. Enable 2-Factor Authentication
3. Search for "App passwords"
4. Create a password for "Mail" → copy into `SMTP_PASS` in `.env`

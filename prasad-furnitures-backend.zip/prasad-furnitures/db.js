// db.js – initializes SQLite database with all tables
const Database = require('better-sqlite3');
const path = require('path');

const DB_PATH = path.join(__dirname, 'data', 'prasad.db');

// Ensure data directory exists
const fs = require('fs');
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new Database(DB_PATH);

// Enable WAL mode for better concurrency
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// ─── Schema ──────────────────────────────────────────────────────────────────
db.exec(`
  -- Products catalog
  CREATE TABLE IF NOT EXISTS products (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    category    TEXT NOT NULL,
    description TEXT,
    badge       TEXT,
    emoji       TEXT DEFAULT '🪑',
    image_url   TEXT,
    price_range TEXT,
    is_featured INTEGER DEFAULT 0,
    sort_order  INTEGER DEFAULT 0,
    created_at  TEXT DEFAULT (datetime('now')),
    updated_at  TEXT DEFAULT (datetime('now'))
  );

  -- Customer enquiries
  CREATE TABLE IF NOT EXISTS enquiries (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    phone       TEXT NOT NULL,
    interest    TEXT,
    message     TEXT,
    source      TEXT DEFAULT 'website',   -- website | whatsapp | walk-in
    status      TEXT DEFAULT 'new',       -- new | contacted | converted | closed
    notes       TEXT,                     -- admin internal notes
    created_at  TEXT DEFAULT (datetime('now')),
    updated_at  TEXT DEFAULT (datetime('now'))
  );

  -- Testimonials
  CREATE TABLE IF NOT EXISTS testimonials (
    id          TEXT PRIMARY KEY,
    author      TEXT NOT NULL,
    location    TEXT,
    text        TEXT NOT NULL,
    stars       INTEGER DEFAULT 5,
    is_visible  INTEGER DEFAULT 1,
    sort_order  INTEGER DEFAULT 0,
    created_at  TEXT DEFAULT (datetime('now'))
  );

  -- Site settings (key-value store for admin-editable content)
  CREATE TABLE IF NOT EXISTS settings (
    key         TEXT PRIMARY KEY,
    value       TEXT,
    label       TEXT,
    updated_at  TEXT DEFAULT (datetime('now'))
  );
`);

// ─── Seed default products (only if empty) ───────────────────────────────────
const productCount = db.prepare('SELECT COUNT(*) as c FROM products').get();
if (productCount.c === 0) {
  const insert = db.prepare(`
    INSERT INTO products (id, name, category, description, badge, emoji, sort_order)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);
  const products = [
    ['prod_1', 'Teakwood Sofa', 'Sofas & Lounges', 'Handcrafted solid teakwood frame with premium cushioning', 'Bestseller', '🛋️', 1],
    ['prod_2', 'Platform Cot', 'Beds & Divans', 'Minimalist platform bed with clean grain finish', 'New Arrival', '🛏️', 2],
    ['prod_3', 'Dining Set', 'Dining Sets', '6-seater dining table with matching chairs', 'Most Popular', '🍽️', 3],
    ['prod_4', 'Accent Chair', 'Accent Chairs', 'Statement single chair for living or reading corners', 'Custom', '🪑', 4],
    ['prod_5', 'Wardrobe', 'Wardrobes / Vanities', 'Full-height wardrobe with sliding or hinged doors', 'Custom', '🚪', 5],
    ['prod_6', 'Dressing Table', 'Wardrobes / Vanities', 'Elegant vanity with mirror and storage drawers', 'Elegant', '🪞', 6],
  ];
  const insertMany = db.transaction((rows) => rows.forEach(r => insert.run(...r)));
  insertMany(products);
}

// ─── Seed default testimonials ───────────────────────────────────────────────
const testiCount = db.prepare('SELECT COUNT(*) as c FROM testimonials').get();
if (testiCount.c === 0) {
  const insert = db.prepare(`
    INSERT INTO testimonials (id, author, location, text, stars, sort_order)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  const testis = [
    ['testi_1', 'Lakshmi Devi', 'Palasa, Srikakulam', 'The minimalist dining table we ordered transformed our space. The grain of the teakwood is stunning, and the craftsmanship is flawless.', 5, 1],
    ['testi_2', 'Ravi Kumar', 'Srikakulam Town', 'We wanted a clean, modern bed frame without sacrificing the durability of solid wood. Prasad Furnitures delivered exactly what we envisioned.', 5, 2],
    ['testi_3', 'Suresh Babu', 'Narasannapeta', 'Their attention to detail and clean finishing sets them apart. The bespoke wardrobe feels like it was built with the house.', 5, 3],
  ];
  const insertMany = db.transaction((rows) => rows.forEach(r => insert.run(...r)));
  insertMany(testis);
}

// ─── Seed default settings ───────────────────────────────────────────────────
const settingCount = db.prepare('SELECT COUNT(*) as c FROM settings').get();
if (settingCount.c === 0) {
  const insert = db.prepare('INSERT INTO settings (key, value, label) VALUES (?, ?, ?)');
  const settings = [
    ['business_name', 'Sri Swamy Krishna Prasad Furnitures', 'Business Name'],
    ['tagline', 'Modern Craft. Timeless Materials.', 'Tagline'],
    ['phone', '86866 03034', 'Phone Number'],
    ['whatsapp', '918686603034', 'WhatsApp Number'],
    ['address', 'Dandi Veedhi, Collector Office Road, Srikakulam, AP', 'Address'],
    ['hours_weekday', 'Monday – Saturday: 9:30 AM – 9:00 PM', 'Weekday Hours'],
    ['hours_sunday', 'Sunday: 9:00 AM – 12:30 PM', 'Sunday Hours'],
  ];
  const insertMany = db.transaction((rows) => rows.forEach(r => insert.run(...r)));
  insertMany(settings);
}

module.exports = db;
